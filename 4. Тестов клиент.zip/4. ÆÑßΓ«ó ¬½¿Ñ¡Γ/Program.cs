﻿using System;
using System.Collections.Generic;
using System.Runtime.CompilerServices;

namespace _4._Тестов_клиент
{
    class Program
    {
        static void Main(string[] args)
        {
            BankAccount account = new BankAccount();
            Dictionary<int, BankAccount> accounts = new Dictionary<int, BankAccount>();
            string command;
            while ((command = Console.ReadLine()) != "End")
            {
                var cmdArgs = command.Split();
                var cmdType = cmdArgs[0];
                switch (cmdType)
                {
                    case "Create":
                        account.Create(cmdArgs, accounts);
                        break;
                    case "Deposit":
                        var cmdDepositArgs = command.Split();
                        var cmdDepositToDouble = cmdDepositArgs[0];
                            account.Deposit(cmdDepositArgs, accounts);
                        break;
                    case "Withdraw":
                        var cmdWithdrawArgs = command.Split();
                        var cmdWithdrawToDouble = cmdWithdrawArgs[0];
                        account.Withdraw(cmdWithdrawArgs, accounts);
                        break;
                    case "Print":
                        var cmdPrintArgs = command.Split();
                        var cmdPrintDouble = cmdPrintArgs[0];
                        account.Print(cmdPrintArgs, accounts);
                        break;
                }
            }

        }
    }
    public class BankAccount
    {
        public int Id;
        public double Balance { get; set; }
        public double amount;
        public void Create(string[] cmdArgs, Dictionary<int, BankAccount> accounts)
        {
            var id = int.Parse(cmdArgs[1]);
            if (accounts.ContainsKey(id))
            {
                Console.WriteLine("Account already exists");
            }
            var acc = new BankAccount();
            acc.Id = id;
            accounts.Add(id, acc);

        }


        public void Deposit(string[] cmdDepositArgs, Dictionary<int, BankAccount> accounts)
        {
            this.Balance += amount;
        }
        public void Withdraw(string[] cmdWithdrawArgs, Dictionary<int, BankAccount> accounts)
        {

            this.Balance -= amount;
            if (Balance < amount)
            {
                Console.WriteLine("Insufficient balance");
            }
        }
        public void Print(string[] cmdPrintArgs, Dictionary<int, BankAccount> accounts)
        {
            Console.WriteLine($"Account ID{Id}, balance {Balance:f2}");
        }
    }
}
