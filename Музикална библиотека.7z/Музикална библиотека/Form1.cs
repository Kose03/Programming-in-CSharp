﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace Музикална_библиотека
{
    public partial class Form1 : Form
    {

        public Form1()
        {
            InitializeComponent();
        }
        private void Form1_Load(object sender, EventArgs e)
        {
            // TODO: This line of code loads data into the 'musicLibraryDataSet.MusicTab' table. You can move, or remove it, as needed.
            this.musicTabTableAdapter.Fill(this.musicLibraryDataSet.MusicTab);
            // TODO: This line of code loads data into the 'musicLibraryDataSet.MusicTab' table. You can move, or remove it, as needed.
            Clear();
            SqlConnection connection = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=MusicLibrary;Integrated Security=True;Pooling=False");
            connection.Open();
            SqlCommand command = new SqlCommand("Select * from MusicTab", connection);
            //command.Parameters.AddWithValue("@GenresID", int.Parse(txtGenresID.Text));
            SqlDataAdapter data = new SqlDataAdapter(command);
            DataTable dataTable = new DataTable();
            data.Fill(dataTable);
            dataGridView1.DataSource = dataTable;
            //this.ActiveControl = txtGenresID;
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            Clear();
        }


        private void Clear()
        {
            txtGenresID.Text = txtGenresName.Text = txtArtistsID.Text = txtArtistsName.Text = txtSales.Text = txtAlbumsName.Text = txtArtistsID.Text = txtAlbumsID.Text = string.Empty;
        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=MusicLibrary;Integrated Security=True;Pooling=False");
            connection.Open();
            SqlCommand command = new SqlCommand("insert into MusicTab values (@GenresID,@GenresName,@ArtistsID,@ArtistsName,@AlbumsID,@AlbumsName,@Sales)", connection);
            command.Parameters.AddWithValue("@GenresID", int.Parse(txtGenresID.Text));
            command.Parameters.AddWithValue("@GenresName", txtGenresName.Text);
            command.Parameters.AddWithValue("@ArtistsID", int.Parse(txtArtistsID.Text));
            command.Parameters.AddWithValue("@ArtistsName", txtArtistsName.Text);
            command.Parameters.AddWithValue("@AlbumsID", txtAlbumsID.Text);
            command.Parameters.AddWithValue("@AlbumsName", txtAlbumsName.Text);
            command.Parameters.AddWithValue("@Sales", txtSales.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Данните са успешно добавени!", "Поздравления!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=MusicLibrary;Integrated Security=True;Pooling=False");
            connection.Open();
            SqlCommand command = new SqlCommand("Update MusicTab set GenresID=@GenresID,GenresName=@GenresName,ArtistsID=@ArtistsID,ArtistsName=@ArtistsName,AlbumsID=@AlbumsID,AlbumsName=@AlbumsName,Sales=@Sales where GenresID=@GenresID", connection);
            command.Parameters.AddWithValue("@GenresID", int.Parse(txtGenresID.Text));
            command.Parameters.AddWithValue("@GenresName", txtGenresName.Text);
            command.Parameters.AddWithValue("@ArtistsID", int.Parse(txtArtistsID.Text));
            command.Parameters.AddWithValue("@ArtistsName", txtArtistsName.Text);
            command.Parameters.AddWithValue("@AlbumsID", txtAlbumsID.Text);
            command.Parameters.AddWithValue("@AlbumsName", txtAlbumsName.Text);
            command.Parameters.AddWithValue("@Sales", txtSales.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Данните са успешно обновени!", "Поздравления!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            SqlConnection connection = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=MusicLibrary;Integrated Security=True;Pooling=False");
            connection.Open();
            SqlCommand command = new SqlCommand("Delete MusicTab where GenresID=@GenresID,GenresName=@GenresName,ArtistsID=@ArtistsID,ArtistsName=@ArtistsName,AlbumsID=@AlbumsID,AlbumsName=@AlbumsName,Sales=@Sales where GenresID=@GenresID", connection);
            command.Parameters.AddWithValue("@GenresID", int.Parse(txtGenresID.Text));
            command.Parameters.AddWithValue("@GenresName", txtGenresName.Text);
            command.Parameters.AddWithValue("@ArtistsID", int.Parse(txtArtistsID.Text));
            command.Parameters.AddWithValue("@ArtistsName", txtArtistsName.Text);
            command.Parameters.AddWithValue("@AlbumsID", txtAlbumsID.Text);
            command.Parameters.AddWithValue("@AlbumsName", txtAlbumsName.Text);
            command.Parameters.AddWithValue("@Sales", txtSales.Text);
            command.ExecuteNonQuery();
            connection.Close();
            MessageBox.Show("Данните са успешно изтрити!", "Поздравления!", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            //SqlConnection connection = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=MusicLibrary;Integrated Security=True;Pooling=False");
            //connection.Open();
            //SqlCommand command = new SqlCommand("Select * from MusicTab where GenresID=@GenresID", connection);
            //command.Parameters.AddWithValue("@GenresID", int.Parse(txtGenresID.Text));
            //SqlDataAdapter data = new SqlDataAdapter(command);
            //DataTable dataTable = new DataTable();
            //data.Fill(dataTable);
            //dataGridView1.DataSource = dataTable;
        }

        private void заПрограматаToolStripMenuItem_Click(object sender, EventArgs e)
        {
            About about = new About();
            about.Visible = true;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            //string mainConn = ConfigurationManager.ConnectionStrings["MyConn"].ConnectionString;
            //SqlConnection sqlConnection = new SqlConnection(mainConn);
            //string sqlQuery = "select * from [dbo].[MusicTab] where GenresID like ('" + txtSearch.Text + "%')";
            ////SqlConnection connection = new SqlConnection("Data Source=localhost\\SQLEXPRESS;Initial Catalog=MusicLibrary;Integrated Security=True;Pooling=False");
            ////string sqlQuery = "select * from [dbo].[MusicTab] where MusicTab='" + txtSearch.Text + "'";
            //sqlConnection.Open();
            //SqlCommand command = new SqlCommand(sqlQuery, sqlConnection);
            //SqlDataAdapter sdr = new SqlDataAdapter(command);
            //DataTable dt = new DataTable();
            //sdr.Fill(dt);
            //dataGridView1.DataSource = dt;
            //sqlConnection.Close();
        }
    }
}
