﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Домашно_по_Увод_в_АСД
{

    public class Program
    {
        static void Main(string[] args)
        {

        }

    }
}
