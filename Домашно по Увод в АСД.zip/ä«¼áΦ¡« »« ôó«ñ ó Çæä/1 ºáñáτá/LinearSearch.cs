﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _1_задача
{
   public class LinearSearch
   
    {
       static void Main(string[] args)
        {
            int[] capacity = new int[100];
            Console.WriteLine("Моля, въведете броя на числата които искате да бъдат в масива!");
            string red1 = Console.ReadLine();
            int x = Int32.Parse(red1);
            Console.WriteLine("-------------------------");
            Console.WriteLine("\n Въведете числата! \n");
            for (int i = 0; i < x; i++)
            {
                string step1 = Console.ReadLine();
                capacity[i] = Int32.Parse(step1);
            }
            Console.WriteLine("-------------------------");
            Console.WriteLine("\n Въведете втория ред от числа! \n");
            for (int i = 0; i < x; i++)
            {
                string step2 = Console.ReadLine();
                capacity[i] = Int32.Parse(step2);
            }
            Console.WriteLine("-------------------------");
            Console.WriteLine("Въведете числото, което искате да потърсите!\n");
            string step2 = Console.ReadLine(); 
            string step3 = Console.ReadLine();
            int x2 = Int32.Parse(step2); 
            int x3 = Int32.Parse(step3);
            for (int i = 0; i < x; i++)
            {
                if (capacity[i] == x3)
                {
                    Console.WriteLine("-------------------------");
                    Console.WriteLine("Търсенето е УСПЕШНО!");
                    Console.WriteLine("Числото {0} е намерено на място {1}\n", x2, x3, i + 1);
                    return;
                }
            }
           Console.WriteLine("ТЪРСЕНЕТО Е НЕУСПЕШНО!");
        }
    }
}
